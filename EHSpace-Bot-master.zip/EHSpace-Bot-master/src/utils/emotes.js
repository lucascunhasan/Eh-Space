const emojis = {
    "success": "<:yes:810577777975099392>",
    "error": "<:no:810577735311163422>",
    "trash": "<:trash:810578395527249941>",
    "bandeira": "<:bandera:810594877070245898>",
    "map": "<:Community:810619247289827349>",
    "mongodb": "<:mongodb:811647987532300328>",
    "clyde": "<:clyde:811654672581787658>",
    "verify": "<:VerifySimbol:822983363744497745>",
    "bot": "<:DK_BOT:823177827544596481>",
    "coin": "<:coin:825737106453692436>",
    "money_wings": "<:transfer:826061828638507029>",
    "currency": "<:moneycurrency:826068051429556274>",
    "translate": "<:translate:826094397044424736>",
    "clandr": "<a:clandr:828368419606757377>",
    "lua": "<a:lua:828336625926930452>",
    "planeta": "<:rocket_planet:826213848914722887>",
    "warn": "<:dk_warn:838902120215871548>"
  }
  
  module.exports = emojis
  